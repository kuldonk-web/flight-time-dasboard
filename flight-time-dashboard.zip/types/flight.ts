/**
 * Status operasional penerbangan.
 * NORMAL  = penerbangan berjalan sesuai rencana
 * RTB     = Return To Base
 * RTA     = Return To Apron
 * DIVERT  = mendarat di bandara alternatif
 */
export type FlightStatus = 'NORMAL' | 'RTB' | 'RTA' | 'DIVERT';

/**
 * Kategori ketepatan waktu, dihitung on-the-fly (tidak disimpan di data).
 * PENDING = waktu aktual belum diisi, belum bisa dihitung.
 */
export type DelayCategory = 'ON_TIME' | 'DELAY' | 'EARLY' | 'PENDING';

export interface FlightLog {
  id: string;
  flightNumber: string;

  // Info pesawat & rute
  aircraftType: string; // e.g. "B738", "A320"
  flightLevel: string; // e.g. "FL350"
  departureAirport: string; // ICAO 4-letter, e.g. "WIII"
  destinationAirport: string; // ICAO 4-letter, e.g. "WARR"

  date: string; // "2026-07-28"

  // Waktu (semua disimpan sebagai ISO datetime string)
  estimatedBlockOff?: string; // ETD block-off (pushback), opsional
  estimatedDeparture: string; // ETD takeoff
  actualDeparture?: string; // ATD takeoff aktual
  estimatedArrival: string; // ETA landing
  actualArrival?: string; // ATA landing aktual

  // Status operasional khusus
  status: FlightStatus;
  statusRemarks?: string; // wajib diisi jika status !== 'NORMAL'

  notes?: string;

  createdAt: string;
  updatedAt: string;
}

/** Payload yang dipakai form, sebelum id/createdAt/updatedAt digenerate. */
export type FlightLogInput = Omit<FlightLog, 'id' | 'createdAt' | 'updatedAt'>;

export interface FlightLogFilterState {
  search: string; // cocok ke flightNumber, departureAirport, destinationAirport
  dateFrom?: string;
  dateTo?: string;
  status?: FlightStatus | 'ALL';
}

export interface FlightStats {
  totalLogs: number;
  onTimeDeparturePct: number;
  onTimeArrivalPct: number;
  avgDepartureDelayMinutes: number;
  avgArrivalDelayMinutes: number;
  rtbCount: number;
  rtaCount: number;
  divertCount: number;
}

/** Bentuk file backup JSON hasil export. */
export interface FlightLogExportPayload {
  version: string;
  exportedAt: string;
  logs: FlightLog[];
}
